/* The Faddeeva.cc file contains macros to let it compile as C code
   (assuming C99 complex-number support), so just #include it. */
#include "Faddeeva.cc"
