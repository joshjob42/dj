#!/bin/sh

set -x

brew update
brew install homebrew/dupes/zlib
brew install curl
brew install libssh2
