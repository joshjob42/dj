valid symmetric matrix (A=A+A^T where A=sparse(magic(4)))              |sym4    
             3             1             1             1
isa                        4             4            10             0
(26I3)          (40I2)          (26I3)              
  1  5  8 10 11
 1 2 3 4 2 3 4 3 4 4
 32  7 12 17 22 17 22 12 27  2
