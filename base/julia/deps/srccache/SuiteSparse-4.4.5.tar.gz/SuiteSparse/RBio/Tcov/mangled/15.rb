invalid symmetric matrix (rectangular)
             3             1             1             1
isa                        6             4            10             0
(26I3)          (40I2)          (26I3)              
  1  5  8 10 11
 1 2 3 4 2 3 4 3 4 4
 32  7 12 17 22 17 22 12 27  2
