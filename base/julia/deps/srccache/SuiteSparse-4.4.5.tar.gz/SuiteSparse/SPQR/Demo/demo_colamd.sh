./qrdemo_gpu A.mtx 2
